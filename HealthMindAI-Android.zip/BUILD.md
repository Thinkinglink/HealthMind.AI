# Building HealthMind AI — APK

This folder is a complete Android project. It compiles to a single APK in about 30 seconds.

---

## Option A — Android Studio (easiest, recommended)

1. **Download Android Studio** if you don't have it:  
   https://developer.android.com/studio

2. **Open this folder** in Android Studio:  
   `File → Open → select this folder`

3. Wait for Gradle to sync (first time downloads ~500MB of SDK, takes a minute).

4. Press the **green Play button** (or `Shift+F10`).  
   It builds and installs directly to any connected phone or emulator.

5. To get the APK file for distribution:  
   `Build → Build Bundle(s) / APK(s) → Build APK(s)`  
   The APK lands in `app/build/outputs/apk/debug/app-debug.apk`

---

## Option B — Command line (if you already have the SDK)

```bash
export ANDROID_HOME=/path/to/sdk

./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

---

## Option C — Online build (no install required)

Upload this zip to **AppGyver**, **Expo EAS**, or use GitHub Actions with
the `nicolo-ribaudo/android-build` action. All of these can build an APK
from a Gradle project in CI with zero local setup.

---

## Publishing to Google Play Store

1. Go to https://play.google.com/console and create a developer account ($25 one-time).
2. Create a new app.
3. Generate a **release signing key** in Android Studio:  
   `Build → Generate Signed Bundle / APK → APK → Create new`
4. Build a release APK: `./gradlew assembleRelease`
5. Upload the signed APK and fill in the store listing.

---

## What's inside the APK

The app is a **WebView shell**. All the actual UI, logic, and data live in
`app/src/main/assets/index.html`. The Android code (`MainActivity.java`) just:

- Opens a full-screen WebView
- Grants location permission automatically
- Enables JavaScript, localStorage, and speech synthesis
- Bundles the HTML/CSS/JS so it works offline with no server

Any time you update the app, just replace `assets/index.html` and rebuild.
No code changes needed in the Java or XML files.
